/*
 * cantp.c
 *
 *  Created on: Jul 23, 2025
 *      Author: surya.p
 */
#include "cantp.h"
#include "main.h"
#include <string.h>
#include <stdbool.h>

//Constants
#define CAN_TP_RX_BUF_SIZE     256
#define CAN_TP_TX_BUF_SIZE     256
#define CAN_TP_CF_FRAME_DATA   7
#define CAN_TP_MAX_CF_SEQ      0x0F
#define FC_TIMEOUT_MS          100

extern CAN_HandleTypeDef hcan1;

//Internal receive buffer
static uint8_t rx_buffer[CAN_TP_RX_BUF_SIZE];
static uint16_t rx_expected_len = 0;
static uint16_t rx_current_len = 0;
static uint8_t rx_next_sn = 1;
static bool rx_in_progress = false;

// TX state variables
static uint8_t tx_buffer[CAN_TP_TX_BUF_SIZE];
static uint16_t tx_total_len = 0;
static uint16_t tx_sent_len = 0;
static uint8_t tx_next_sn = 1;
bool tx_in_progress = false;
static uint32_t tx_can_id = 0;
static bool tx_wait_fc = false;
static uint32_t fc_wait_start_tick = 0;

// Prototypes
void can_tp_handle_fc(uint8_t* data);
void uds_process_request(uint8_t* data, uint16_t len);
void uds_dispatcher_handle(uint8_t* data, uint16_t len);

void can_send(uint32_t id, uint8_t* data, uint8_t len)
{
    CAN_TxHeaderTypeDef txHeader;
    uint32_t txMailbox;

    txHeader.StdId = id;
    txHeader.ExtId = 0;
    txHeader.IDE = CAN_ID_STD;
    txHeader.RTR = CAN_RTR_DATA;
    txHeader.DLC = len;
    txHeader.TransmitGlobalTime = DISABLE;

    HAL_CAN_AddTxMessage(&hcan1, &txHeader, data, &txMailbox);
}

static void can_tp_send_flow_control(uint32_t tx_id)
{
    uint8_t fc_frame[8] = { 0x30, 0x00, 0x00 }; // FC | CTS | BS=0 | STmin=0
    can_send(tx_id, fc_frame, 8);
}

void can_tp_receive_isr(uint32_t can_id, uint8_t* data, uint8_t len)
{
    uint8_t pci = data[0];
    uint8_t pci_type = pci >> 4;

    switch (pci_type)
    {
        case 0x0: // Single Frame
        {
            uint8_t sf_len = pci & 0x0F;
            if (sf_len > 7 || len < (sf_len + 1)) return;
            uds_process_request(&data[1], sf_len);
            break;
        }

        case 0x1: // First Frame
        {
            rx_expected_len = ((pci & 0x0F) << 8) | data[1];
            if (rx_expected_len > CAN_TP_RX_BUF_SIZE) return;

            uint8_t first_data_len = len - 2;
            memcpy(rx_buffer, &data[2], first_data_len);
            rx_current_len = first_data_len;
            rx_next_sn = 1;
            rx_in_progress = true;

            can_tp_send_flow_control(can_id);
            break;
        }

        case 0x2: // Consecutive Frame
        {
            if (!rx_in_progress) return;

            uint8_t seq_num = pci & 0x0F;
            if (seq_num != rx_next_sn) {
                rx_in_progress = false;
                return;
            }

            uint8_t copy_len = len - 1;
            if ((rx_current_len + copy_len) > rx_expected_len)
                copy_len = rx_expected_len - rx_current_len;

            memcpy(&rx_buffer[rx_current_len], &data[1], copy_len);
            rx_current_len += copy_len;
            rx_next_sn = (rx_next_sn + 1) & CAN_TP_MAX_CF_SEQ;

            if (rx_current_len >= rx_expected_len) {
                uds_dispatcher_handle(rx_buffer, rx_expected_len);
                rx_in_progress = false;
            }
            break;
        }

        case 0x3: // Flow Control
        {
            can_tp_handle_fc(data);
            break;
        }

        default:
            break;
    }
}

void can_tp_handle_fc(uint8_t* data)
{
    if ((data[0] & 0xF0) != 0x30) return;
    tx_wait_fc = false;
}

void can_tp_send(uint32_t can_id, uint8_t* data, uint16_t len)
{
    if (tx_in_progress) return;

    tx_can_id = can_id;
    tx_total_len = len;
    tx_sent_len = 0;
    tx_next_sn = 1;
    tx_wait_fc = true;
    tx_in_progress = true;

    if (len <= 7) {
        uint8_t sf_frame[8] = { 0 };
        sf_frame[0] = 0x00 | (len & 0x0F);
        memcpy(&sf_frame[1], data, len);
        //can_send(can_id, sf_frame, len + 1);
        send_can_message(sf_frame, len + 1) ;

        tx_in_progress = false;
    } else {
        memcpy(tx_buffer, data, len);

        uint8_t ff_frame[8] = { 0 };
        ff_frame[0] = 0x10 | ((len >> 8) & 0x0F);
        ff_frame[1] = len & 0xFF;
        memcpy(&ff_frame[2], &tx_buffer[0], 6);

        //can_send(can_id, ff_frame, 8);
        send_can_message(ff_frame, 8) ;
        tx_sent_len = 6;
        tx_wait_fc = false;
        fc_wait_start_tick = HAL_GetTick();
        //tx_in_progress=true;
    }
}

void can_tp_tx_task(void)
{
    if (!tx_in_progress) return;

    if (tx_wait_fc) {
        if (HAL_GetTick() - fc_wait_start_tick > FC_TIMEOUT_MS) {
            tx_in_progress = false; // Timeout
        }
        return;
    }

    if (tx_sent_len >= tx_total_len) {
        tx_in_progress = false;
        a=0;
        return;
    }

    uint8_t cf_frame[8] = { 0 };
    cf_frame[0] = 0x20 | (tx_next_sn & 0x0F);
    uint8_t remaining = tx_total_len - tx_sent_len;
    uint8_t copy_len = (remaining > CAN_TP_CF_FRAME_DATA) ? CAN_TP_CF_FRAME_DATA : remaining;

    memcpy(&cf_frame[1], &tx_buffer[tx_sent_len], copy_len);
    //can_send(tx_can_id, cf_frame, copy_len + 1);
    send_can_message(cf_frame, copy_len + 1) ;
    tx_sent_len += copy_len;
    tx_next_sn = (tx_next_sn + 1) & 0x0F;

}
/*#include "cantp.h"
#include <string.h>
#include <stdbool.h>
#include "main.h"

#define CAN_TP_BUFFER_SIZE 512
#define CAN_TP_BLOCK_SIZE 8
#define CAN_TP_TIMEOUT_MS 100

// Internal state
static struct {
    uint8_t rx_buffer[CAN_TP_BUFFER_SIZE];
    uint16_t rx_len;
    uint16_t rx_index;
    uint8_t expected_sn;
    bool receiving;

    uint8_t tx_buffer[CAN_TP_BUFFER_SIZE];
    uint16_t tx_len;
    uint16_t tx_index;
    uint8_t next_sn;
    bool transmitting;

    uint32_t rx_id;
    uint32_t tx_id;
} tp_ctx;

extern CAN_HandleTypeDef hcan1;

void uds_process_request(uint8_t data, uint16_t len);
void can_send(uint32_t id, uint8_t* data, uint8_t len); // HAL Layer

void can_tp_init(void) {
    memset(&tp_ctx, 0, sizeof(tp_ctx));
}

bool can_tp_send(uint32_t id, uint8_t data, uint16_t len) {
    if (len <= 7) {
        uint8_t sf[8] = {0};
        sf[0] = 0x00 | (len & 0x0F);
        memcpy(&sf[1], data, len);
        can_send(id, sf, len + 1);
    } else {
        tp_ctx.tx_id = id;
        tp_ctx.tx_len = len;
        tp_ctx.tx_index = 6;
        tp_ctx.next_sn = 1;
        tp_ctx.transmitting = true;

        uint8_t ff[8] = {0x10 | ((len >> 8) & 0x0F), len & 0xFF};
        memcpy(&ff[2], data, 6);
        can_send(id, ff, 8);
    }
    return true;
}

void can_tp_receive_isr(uint32_t can_id, uint8_t* data, uint8_t len) {
    uint8_t pci_type = data[0] >> 4;
    if (pci_type == 0x0) { // SF
        uint8_t dlen = data[0] & 0x0F;
        memcpy(tp_ctx.rx_buffer, &data[1], dlen);
        uds_process_request(tp_ctx.rx_buffer, dlen);

    } else if (pci_type == 0x1) { // FF
        tp_ctx.rx_len = ((data[0] & 0x0F) << 8) | data[1];
        memcpy(tp_ctx.rx_buffer, &data[2], 6);
        tp_ctx.rx_index = 6;
        tp_ctx.expected_sn = 1;
        tp_ctx.receiving = true;

        uint8_t fc[8] = {0x30, 0x00, 0x00};
        can_send(can_id, fc, 3);

    } else if (pci_type == 0x2 && tp_ctx.receiving) { // CF
        uint8_t sn = data[0] & 0x0F;
        if (sn != tp_ctx.expected_sn) {
            tp_ctx.receiving = false;
            return;
        }
        tp_ctx.expected_sn++;
        uint8_t copy_len = (tp_ctx.rx_len - tp_ctx.rx_index >= 7) ? 7 : (tp_ctx.rx_len - tp_ctx.rx_index);
        memcpy(&tp_ctx.rx_buffer[tp_ctx.rx_index], &data[1], copy_len);
        tp_ctx.rx_index += copy_len;

        if (tp_ctx.rx_index >= tp_ctx.rx_len) {
            tp_ctx.receiving = false;
            uds_process_request(tp_ctx.rx_buffer, tp_ctx.rx_len);
        }
    }
}

void can_tp_periodic_task(void) {
    if (tp_ctx.transmitting) {
        if (tp_ctx.tx_index >= tp_ctx.tx_len) {
            tp_ctx.transmitting = false;
            return;
        }

        uint8_t cf[8] = {0x20 | (tp_ctx.next_sn++ & 0x0F)};
        uint8_t seg_len = (tp_ctx.tx_len - tp_ctx.tx_index > 7) ? 7 : tp_ctx.tx_len - tp_ctx.tx_index;
        memcpy(&cf[1], &tp_ctx.tx_buffer[tp_ctx.tx_index], seg_len);
        tp_ctx.tx_index += seg_len;

        can_send(tp_ctx.tx_id, cf, seg_len + 1);
    }
}

void can_send(uint32_t id, uint8_t* data, uint8_t len)
{
    CAN_TxHeaderTypeDef txHeader;
    uint32_t txMailbox;

    txHeader.StdId = id;
    txHeader.ExtId = 0;
    txHeader.IDE = CAN_ID_STD;
    txHeader.RTR = CAN_RTR_DATA;
    txHeader.DLC = len;
    txHeader.TransmitGlobalTime = DISABLE;

    HAL_CAN_AddTxMessage(&hcan1, &txHeader, data, &txMailbox);
}
*/
