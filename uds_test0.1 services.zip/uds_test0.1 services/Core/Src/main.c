/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdio.h>
#include "stm32f4xx_hal.h"
#include "main.h"
#include "uds_services.h"
#include"cantp.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CAN_HandleTypeDef hcan1;

UART_HandleTypeDef huart2;
CAN_RxHeaderTypeDef RxHeader;

uint8_t suppress;
extern uint8_t request_session;
int a=0;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_CAN1_Init(void);
static void MX_USART2_UART_Init(void);
void CAN_Filter_Config(void);
/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_CAN1_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
  CAN_Filter_Config();
  // Envoyer un message de test via UART
    const char *test_msg = "UART Initialized Successfully!\r\n";
    HAL_UART_Transmit(&huart2, (uint8_t*)test_msg, strlen(test_msg), HAL_MAX_DELAY);

    // Activer les notifications pour les interruptions CAN
    if (HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING | CAN_IT_TX_MAILBOX_EMPTY) != HAL_OK)
    {
        Error_handler();
    }

    // D�marrer le module CAN
    if (HAL_CAN_Start(&hcan1) != HAL_OK)
    {
        Error_handler();
    }

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  if(a)
	  {
	  can_tp_tx_task();
	  }
	//  can_tp_periodic_task();
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_handler();
  }
}

/**
  * @brief CAN1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_CAN1_Init(void)
{

  /* USER CODE BEGIN CAN1_Init 0 */

  /* USER CODE END CAN1_Init 0 */

  /* USER CODE BEGIN CAN1_Init 1 */

  /* USER CODE END CAN1_Init 1 */
  hcan1.Instance = CAN1;
  hcan1.Init.Prescaler = 6;
  hcan1.Init.Mode = CAN_MODE_NORMAL;
  hcan1.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan1.Init.TimeSeg1 = CAN_BS1_11TQ;
  hcan1.Init.TimeSeg2 = CAN_BS2_2TQ;
  hcan1.Init.TimeTriggeredMode = DISABLE;
  hcan1.Init.AutoBusOff = DISABLE;
  hcan1.Init.AutoWakeUp = DISABLE;
  hcan1.Init.AutoRetransmission = ENABLE;
  hcan1.Init.ReceiveFifoLocked = DISABLE;
  hcan1.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan1) != HAL_OK)
  {
    Error_handler();
  }
  /* USER CODE BEGIN CAN1_Init 2 */

  /* USER CODE END CAN1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void CAN_Filter_Config(void)
{
    CAN_FilterTypeDef can1_filter_init;

    can1_filter_init.FilterActivation = ENABLE;
    can1_filter_init.FilterBank = 0;
    can1_filter_init.FilterFIFOAssignment = CAN_RX_FIFO0;
    can1_filter_init.FilterIdHigh = 0x0000;
    can1_filter_init.FilterIdLow = 0x0000;
    can1_filter_init.FilterMaskIdHigh = 0X01C0;
    can1_filter_init.FilterMaskIdLow = 0x0000;
    can1_filter_init.FilterMode = CAN_FILTERMODE_IDMASK;
    can1_filter_init.FilterScale = CAN_FILTERSCALE_32BIT;

    if (HAL_CAN_ConfigFilter(&hcan1, &can1_filter_init) != HAL_OK)
    {
        Error_handler();
    }
}

/* Function to send messages via UART */
void UART2_Send(const char* message)
{
    HAL_UART_Transmit(&huart2, (uint8_t*)message, strlen(message), HAL_MAX_DELAY);
}
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
    uint8_t rcvd_msg[8];
    uint8_t response[3];
    if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &RxHeader, rcvd_msg) == HAL_OK)
    {
        // Construction du message � envoyer via UART
        char msg[100];
        sprintf(msg, "Message CAN re�u: ID=0x%lX, Data=[%d, %d, %d, %d, %d, %d, %d, %d]\n",
                (unsigned long)RxHeader.StdId, rcvd_msg[0], rcvd_msg[1], rcvd_msg[2], rcvd_msg[3], rcvd_msg[4], rcvd_msg[5], rcvd_msg[6], rcvd_msg[7]);

        // Envoyer le message UART
        UART2_Send(msg);
if(RxHeader.StdId==0x600)
{
	if(rcvd_msg[1] == 0x04)
	{
	 uint8_t message[8] = {0};
	message[0]=uds_session.current_session;
	 CAN_TxHeaderTypeDef TxHeader;
	    uint32_t TxMailbox;

	    TxHeader.DLC = 8;
	    TxHeader.StdId = 0x608; // Identifiant standard UDS pour l'ECU
	    TxHeader.IDE = CAN_ID_STD;
	    TxHeader.RTR = CAN_RTR_DATA;

	    if (HAL_CAN_AddTxMessage(&hcan1, &TxHeader, message, &TxMailbox) != HAL_OK) {
	        // G�rer l'erreur d'envoi
	        Error_handler();
	    }
	}
}
else
{
	uint8_t frametype=((rcvd_msg[0] & 0xf0)>>4);
	uint8_t len = rcvd_msg[0] & 0x0f;
	if(frametype==0)
	{
	    // Identifier le service UDS bas� sur le premier octet du message
        switch (rcvd_msg[1]) {
            case UDS_DIAGNOSTIC_SESSION_CONTROL:
            	//checking suppressPosRspMsgIndicationBit true or false
            	suppress = rcvd_msg[2] & 0x80;
            	rcvd_msg[2] = rcvd_msg[2] & 0x0F;
                // Appeler la fonction pour le service Diagnostic Session Control
                uds_diagnostic_session_control(rcvd_msg[2], len);
                break;

            case UDS_ECU_RESET:
            	//checking suppressPosRspMsgIndicationBit true or false
            	 suppress = rcvd_msg[2] & 0x80;
            	 rcvd_msg[2] = rcvd_msg[2] & 0x0F;
                // Appeler la fonction pour le service ECU Reset avec le resetType
                uds_ecu_reset
				(rcvd_msg[2]);
                break;
            case UDS_SECURITY_ACCESS:
                // Appeler directement la fonction pour le service Security Access
                uds_security_access(rcvd_msg[1], &rcvd_msg[2], RxHeader.DLC - 2);
                break;
            case UDS_COMMUNICATION_CONTROL:
                uds_communication_control(rcvd_msg[1]);
                break;
            case UDS_TESTER_PRESENT:
                // Appeler la fonction pour le service TesterPresent
                uds_tester_present(rcvd_msg[1]);
                break;
            case UDS_ACCESS_TIMING_PARAMETER:
                // Appeler la fonction pour le service Access Timing Parameter
                uds_access_timing_parameter(rcvd_msg[1], &rcvd_msg[2], RxHeader.DLC - 2);
                break;
            case UDS_SECURED_DATA_TRANSMISSION:
                // Appeler la fonction pour le service Secured Data Transmission
                uds_secured_data_transmission(&rcvd_msg[1], RxHeader.DLC - 1);
                break;
            case UDS_CONTROL_DTC_SETTING:
                // Appeler la fonction pour le service ControlDTCSetting
                uds_control_dtc_setting(rcvd_msg[1]);
                break;
            case UDS_RESPONSE_ON_EVENT:
                // Appeler la fonction pour le service ResponseOnEvent
                uds_response_on_event(rcvd_msg[1], &rcvd_msg[2], RxHeader.DLC - 2);
                break;
            case UDS_LINK_CONTROL:
                // Appeler la fonction pour le service LinkControl
                uds_link_control(rcvd_msg[1], &rcvd_msg[2], RxHeader.DLC - 2);
                break;
            case UDS_READ_DATA_BY_IDENTIFIER:
                // Appeler la fonction pour le service ReadDataByIdentifier
                uds_read_data_by_identifier(&rcvd_msg[2], len - 1);
                break;
            case UDS_READ_DATA_BY_PERIODIC_IDENTIFIER:
                // Appeler la fonction pour le service ReadDataByPeriodicIdentifier
                uds_read_data_by_periodic_identifier(&rcvd_msg[1], RxHeader.DLC - 1);
                break;
            case UDS_DYNAMICAL_DEFINE_DATA_IDENTIFIER:
                // Appeler la fonction pour le service DynamicallyDefineDataIdentifier
                uds_dynamically_define_data_identifier(rcvd_msg[1], &rcvd_msg[2], RxHeader.DLC - 2);
                break;
            case UDS_WRITE_DATA_BY_IDENTIFIER:
                // Appeler la fonction pour le service WriteDataByIdentifier
                uds_write_data_by_identifier(&rcvd_msg[1], RxHeader.DLC - 1);
                break;
            case UDS_CLEAR_DIAGNOSTIC_INFORMATION:
                // Appeler la fonction pour le service ClearDiagnosticInformation
                uds_clear_diagnostic_information(&rcvd_msg[1], RxHeader.DLC - 1);
                break;
            case UDS_READ_DTC_INFORMATION:
                // Appeler la fonction pour g�rer le service ReadDTCInformation
                uds_read_dtc_information(rcvd_msg[1], &rcvd_msg[2], RxHeader.DLC - 2);
                break;
            case UDS_INPUT_OUTPUT_CONTROL_BY_IDENTIFIER:
                uds_input_output_control_by_identifier((IOControlRequest_t *)&rcvd_msg[1], NULL);
                break;
            case UDS_ROUTINE_CONTROL:
                uds_routine_control((RoutineControlRequest_t *)&rcvd_msg[1], NULL);
                break;
            case UDS_REQUEST_DOWNLOAD:
                uds_request_download((RequestDownload_t *)&rcvd_msg[1]);
                break;
            case UDS_REQUEST_UPLOAD:
                uds_request_upload((RequestUpload_t *)&rcvd_msg[1]);
                break;
            case UDS_TRANSFER_DATA:
                uds_transfer_data((RequestTransferData_t *)&rcvd_msg[1]);
                break;
            case UDS_REQUEST_TRANSFER_EXIT:
                uds_request_transfer_exit((RequestTransferExit_t *)&rcvd_msg[1], NULL);
                break;
            case UDS_REQUEST_FILE_TRANSFER:
                uds_request_file_transfer((RequestFileTransfer_t *)&rcvd_msg[1]);
                 break;

            default:
              // Remplir le message de r�ponse n�gative pour un service non support�
              response[0] = UDS_NEGATIVE_RESPONSE;         // R�ponse n�gative g�n�rique
              response[1] = rcvd_msg[0];  // Service non support�
              response[2] = NRC_SERVICE_NOT_SUPPORTED;         // Code NRC (ServiceNotSupported)

              // Envoyer le message de r�ponse n�gative via CAN
              send_can_message(response, 3);
             break;
        }
	}
	else if (frametype==3)
	{
		a= 1;
	}

}
    }
}
void HAL_CAN_TxMailbox0CompleteCallback(CAN_HandleTypeDef *hcan)
{
    char msg[50];
    sprintf(msg, "Message Transmitted:M0\r\n");
    HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
extern void Error_handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
