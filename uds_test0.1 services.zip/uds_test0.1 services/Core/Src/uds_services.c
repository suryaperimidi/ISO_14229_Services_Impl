/*
 * d.c
 *
 *  Created on: Jul 9, 2025
 *      Author: suneel.kataraki
 */


#include "uds_services.h"
#include "stm32f4xx_hal.h"
#include <string.h>
#include <stdlib.h>


extern CAN_HandleTypeDef hcan1; // D�claration du handle CAN

